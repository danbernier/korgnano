package korgnano;

public enum ButtonMode {
  Toggle, Momentary
}
